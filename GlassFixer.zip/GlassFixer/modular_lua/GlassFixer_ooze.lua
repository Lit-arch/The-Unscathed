function GlassFixer_ooze_main()
    local targets = selecttargets("Enemy99")

    for i = 1, #targets do
        local t = targets[i]
        local oozeStacks = getbuff(t, "GF_Ooze", "stack")

        if oozeStacks > 0 then
            local instid = getinstid(t)
            local round = getround()
            local seed = instid + round

            local remaining = oozeStacks

            while remaining > 0 do
                buff(t, "GF_Ooze", -1, 0, 0)
                remaining = remaining - 1

                -- Roll for TARGET
                seed = (seed * 1103515245 + 12345) % 2147483648
                local targetRoll = (seed % 4) + 1
                seed = (seed * 1103515245 + 12345) % 2147483648
                local targetAmount = (seed % 4) + 1

                -- Roll for SELF (different seed to avoid same rolls type shit)
                seed = (seed * 1103515245 + 12345) % 2147483648
                local selfRoll = (seed % 4) + 1
                seed = (seed * 1103515245 + 12345) % 2147483648
                local selfAmount = (seed % 2) + 1

                log("target roll=" .. tostring(targetRoll) .. " amount=" .. tostring(targetAmount) .. " | self roll=" .. tostring(selfRoll) .. " amount=" .. tostring(selfAmount))

                -- Apply to TARGET
                if targetRoll == 1 then
                    buff(t, "DefenseDown", targetAmount, 0, 1)
                elseif targetRoll == 2 then
                    buff(t, "DefenseUp", targetAmount, 0, 1)
                elseif targetRoll == 3 then
                    buff(t, "AttackDown", targetAmount, 0, 1)
                else
                    buff(t, "AttackUp", targetAmount, 0, 1)
                end

                -- Apply to SELF
                if selfRoll == 1 then
                    buff("Self", "DefenseDown", selfAmount, 0, 1)
                elseif selfRoll == 2 then
                    buff("Self", "DefenseUp", selfAmount, 0, 1)
                elseif selfRoll == 3 then
                    buff("Self", "AttackDown", selfAmount, 0, 1)
                else
                    buff("Self", "AttackUp", selfAmount, 0, 1)
                end
            end
        end
    end
end